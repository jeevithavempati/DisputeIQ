
-- Staging table for authorization-like events used for bulk scoring
CREATE TABLE IF NOT EXISTS dispute_poc.auth_events (
  auth_id VARCHAR(36) PRIMARY KEY,
  txn_ts TIMESTAMP NOT NULL,
  customer_id VARCHAR(36) NOT NULL,
  card_id VARCHAR(19),
  merchant_id VARCHAR(20) NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  currency CHAR(3) DEFAULT 'USD',
  is_ecommerce BOOLEAN DEFAULT TRUE,
  is_cross_border BOOLEAN DEFAULT FALSE,
  mcc CHAR(4)
);
-- Example COPY command (adjust path and permissions):
-- \COPY dispute_poc.auth_events FROM 'authorizations_part_01.csv' WITH (FORMAT csv, HEADER true);

-- Bulk scoring example:
-- SELECT a.auth_id, s.*
-- FROM dispute_poc.auth_events a
-- CROSS JOIN LATERAL dispute_poc.score_dispute_risk(a.customer_id, a.merchant_id, a.amount, a.is_ecommerce, a.is_cross_border) s;
