# Tuned Scaled Generator (v2)

Config-driven tuning for:
- **E-commerce share** by merchant type (e.g., DIGITAL_GOODS, GAMING)
- **Cross-border intensity** by merchant country (e.g., Japan=392, UAE=784, UK=826)
- **Amount distributions** by merchant type (e.g., TRAVEL higher ticket size)
- **Target dispute base-rate** and **fraud share** for the sample `disputes.csv`

## Run for 1M authorizations
```bash
python data_generator_v2.py   --customers 50000   --merchants 2000   --auths 1000000   --partitions 20   --out ./out_50k_1M_tuned   --config ./tuned_config.json
```
