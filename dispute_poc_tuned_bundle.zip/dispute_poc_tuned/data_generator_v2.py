#!/usr/bin/env python3
"""
Dispute PoC Scaled Data Generator (v2, Tunable)
------------------------------------------------
... (shortened header for brevity in generator file) ...
"""
import argparse, csv, os, uuid, random, datetime, math, json
from pathlib import Path

random.seed(42)

def u():
    return str(uuid.uuid4())

COUNTRY_ALPHA2 = ['IN','US','GB','CA','AU','JP','SG','DE','FR','AE','BR']
COUNTRY_NUMERIC = ['356','840','826','124','036','392','702','276','250','784','076']
CARD_NETWORKS = ['VISA','MASTERCARD','RUPAY','AMEX']
CARD_TYPES = ['CREDIT','DEBIT']
MERCHANT_TYPES = ['MARKETPLACE','SUBSCRIPTION','TRAVEL','DIGITAL_GOODS','GAMING','FOOD_DELIVERY','APPAREL','ELECTRONICS','RESTAURANT','GROCERY']
STATUSES = ['ACTIVE','BLOCKED','CLOSED']
DISPUTE_STATUSES = ['OPEN','PENDING','WON','LOST','CLOSED']
REASON_CODES = ['FRAUD','NO_AUTH','NOT_AS_DESCRIBED','DUPLICATE','REFUND_NOT_PROCESSED']

DEFAULT_CFG = {
  "ecom_boost_by_merchant_type": {"DIGITAL_GOODS":0.9, "GAMING":0.85, "MARKETPLACE":0.8, "TRAVEL":0.7},
  "cross_border_boost_by_merchant_country": {"392":1.5, "784":1.6, "826":1.2},
  "amount_multipliers_by_merchant_type": {"TRAVEL":1.8, "ELECTRONICS":1.5, "APPAREL":1.1, "GROCERY":0.6},
  "target_dispute_rate": 0.012,
  "fraud_ratio_of_disputes": 0.35
}


def load_cfg(path):
    if path and os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return DEFAULT_CFG


def gen_customers(n):
    customers = []
    now = datetime.datetime.now()
    for _ in range(n):
        created = now - datetime.timedelta(days=random.randint(30, 5000))
        customers.append({
            'customer_id': u(),
            'home_country': random.choice(COUNTRY_ALPHA2),
            'card_tenure_days': random.randint(30, 3000),
            'risk_segment': random.choice(['LOW','MED','HIGH']),
            'avg_spend_baseline': round(random.uniform(500, 30000), 2),
            'created_at': created.strftime('%Y-%m-%d %H:%M:%S')
        })
    return customers


def gen_cards(customers, approx_cards_per_customer=1.2):
    cards = []
    total_cards = int(len(customers) * approx_cards_per_customer)
    for _ in range(total_cards):
        c = random.choice(customers)
        pan = ''.join(str(random.randint(0,9)) for _ in range(16))
        issued = datetime.date(2018,1,1) + datetime.timedelta(days=random.randint(0, 3000))
        cards.append({
            'card_id': pan,
            'customer_id': c['customer_id'],
            'card_type': random.choice(CARD_TYPES),
            'network': random.choice(CARD_NETWORKS),
            'issued_at': issued.isoformat(),
            'status': random.choice(STATUSES)
        })
    return cards


def gen_merchants(n):
    merchants = []
    now = datetime.datetime.now()
    for i in range(n):
        created = now - datetime.timedelta(days=random.randint(30, 2500))
        merchants.append({
            'merchant_id': f'M{100000+i}',
            'mcc': str(random.randint(5000, 5999)),
            'merchant_type': random.choice(MERCHANT_TYPES),
            'country': random.choice(COUNTRY_NUMERIC),
            'merchant_tenure_days': random.randint(15, 2500),
            'created_at': created.strftime('%Y-%m-%d %H:%M:%S')
        })
    return merchants


def gen_merchant_reputation(merchants):
    out = []
    for m in merchants:
        dr90 = round(random.uniform(0.002, 0.06), 4)
        dr30 = round(max(0, dr90 + random.uniform(-0.01, 0.02)), 4)
        fr90 = round(random.uniform(0.001, 0.03), 4)
        rr30 = round(random.uniform(0.005, 0.1), 4)
        vol90 = random.randint(500, 500000)
        avg_ticket = round(random.uniform(10, 800), 2)
        risk_score = round(min(0.9999, dr30*2 + fr90*3 + rr30), 4)
        bucket = 'LOW' if risk_score < 0.05 else ('MEDIUM' if risk_score < 0.12 else 'HIGH')
        out.append({
            'merchant_id': m['merchant_id'],
            'dispute_rate_30d': dr30,
            'dispute_rate_90d': dr90,
            'fraud_rate_90d': fr90,
            'refund_rate_30d': rr30,
            'total_txn_volume_90d': vol90,
            'avg_ticket_size': avg_ticket,
            'risk_score': risk_score,
            'risk_bucket': bucket,
            'network_monitoring_flag': random.choice([True, False]),
            'last_updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    return out


def gen_customer_behavior(customers):
    out = []
    for c in customers:
        txn30 = random.randint(1, 200)
        spend30 = round(random.uniform(1000, 200000), 2)
        avg_amt30 = round(spend30/txn30, 2)
        max_amt30 = round(avg_amt30 * random.uniform(1.5, 8), 2)
        std_amt30 = round(avg_amt30 * random.uniform(0.2, 2.5), 4)
        out.append({
            'customer_id': c['customer_id'],
            'txn_count_1d': random.randint(0, 10),
            'txn_count_7d': random.randint(0, 50),
            'txn_count_30d': txn30,
            'spend_1d': round(random.uniform(0, 10000), 2),
            'spend_7d': round(random.uniform(0, 50000), 2),
            'spend_30d': spend30,
            'avg_amount_30d': avg_amt30,
            'max_amount_30d': max_amt30,
            'std_amount_30d': std_amt30,
            'unique_merchants_7d': random.randint(1, 20),
            'unique_countries_30d': random.randint(1, 6),
            'ecommerce_ratio_30d': round(random.uniform(0.2, 1.0), 4),
            'cross_border_ratio_30d': round(random.uniform(0.0, 0.9), 4),
            'new_merchants_7d': random.randint(0, 10),
            'disputes_30d': random.randint(0, 6),
            'disputes_90d': random.randint(0, 15),
            'refunds_30d': random.randint(0, 10),
            'days_since_last_txn': random.randint(0, 20),
            'days_since_last_dispute': random.randint(0, 150),
            'customer_age_days': random.randint(30, 6000),
            'risk_score': round(random.uniform(0.01, 0.3), 4),
            'risk_bucket': random.choice(['LOW','MEDIUM','HIGH']),
            'last_updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    return out


def gen_merchant_behavior(merchants):
    out = []
    for m in merchants:
        txn30 = random.randint(200, 100000)
        vol30 = round(random.uniform(50000, 10_000_000), 2)
        avg_ticket = round(vol30/max(1, txn30), 2)
        dr30 = round(random.uniform(0.001, 0.08), 4)
        dr90 = round(max(0, dr30 + random.uniform(-0.02, 0.02)), 4)
        fr90 = round(random.uniform(0.0, 0.03), 4)
        refunds30 = random.randint(0, 1000)
        rr30 = round(refunds30 / max(1, txn30), 4)
        out.append({
            'merchant_id': m['merchant_id'],
            'txn_count_1d': random.randint(0, 4000),
            'txn_count_7d': random.randint(10, 30000),
            'txn_count_30d': txn30,
            'volume_1d': round(random.uniform(1000, 400000), 2),
            'volume_30d': vol30,
            'avg_ticket_size': avg_ticket,
            'unique_customers_30d': random.randint(50, 50000),
            'cross_border_ratio_30d': round(random.uniform(0.0, 0.9), 4),
            'ecommerce_ratio_30d': round(random.uniform(0.3, 1.0), 4),
            'refund_count_30d': refunds30,
            'refund_rate_30d': rr30,
            'dispute_count_30d': int(dr30 * txn30),
            'dispute_count_90d': int(dr90 * txn30 * 3),
            'dispute_rate_30d': dr30,
            'dispute_rate_90d': dr90,
            'fraud_dispute_rate_90d': fr90,
            'chargeback_amount_90d': round(random.uniform(1000, 200000), 2),
            'days_since_onboarding': random.randint(10, 2500),
            'monitoring_flag': random.choice([True, False]),
            'risk_score': round(min(0.9999, dr30*2 + fr90*3 + rr30), 4),
            'risk_bucket': random.choice(['LOW','MEDIUM','HIGH']),
            'last_updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    return out


def write_csv(path, rows, fieldnames=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def gen_authorizations(customers, cards, merchants, customer_behavior, cfg, n, partitions, out_dir):
    # Build lookups
    cards_by_customer = {}
    for card in cards:
        cards_by_customer.setdefault(card['customer_id'], []).append(card)
    cb = {r['customer_id']: r for r in customer_behavior}

    per_part = math.ceil(n / partitions)
    now = datetime.datetime.now()

    ecom_boost = cfg.get('ecom_boost_by_merchant_type', {})
    xb_boost = cfg.get('cross_border_boost_by_merchant_country', {})
    amt_mult = cfg.get('amount_multipliers_by_merchant_type', {})

    for p in range(partitions):
        rows = []
        count = per_part if (p < partitions-1) else (n - per_part*(partitions-1))
        for _ in range(count):
            cust = random.choice(customers)
            cust_id = cust['customer_id']
            eligible_cards = cards_by_customer.get(cust_id)
            if not eligible_cards:
                pan = ''.join(str(random.randint(0,9)) for _ in range(16))
                eligible_cards = [{'card_id': pan, 'customer_id': cust_id, 'card_type': 'CREDIT', 'network': 'VISA', 'issued_at': '2021-01-01', 'status': 'ACTIVE'}]
            card = random.choice(eligible_cards)
            merch = random.choice(merchants)
            mt = merch['merchant_type']

            # Amount
            base = max(30, float(cust['avg_spend_baseline'])/10)
            amount = random.lognormvariate(math.log(base), 0.8)
            amount *= float(amt_mult.get(mt, 1.0))
            amount = round(min(amount, 15000.0), 2)

            cbr = cb[cust_id]
            pe = max(float(cbr['ecommerce_ratio_30d']), float(ecom_boost.get(mt, 0)))
            is_ecom = (random.random() < min(1.0, pe))

            pxb = float(cbr['cross_border_ratio_30d']) * float(xb_boost.get(merch['country'], 1.0))
            pxb = min(pxb, 0.98)
            is_xb = (random.random() < pxb)

            txn_ts = now - datetime.timedelta(days=random.randint(0, 60), seconds=random.randint(0, 86400))

            rows.append({
                'auth_id': u(),
                'txn_ts': txn_ts.strftime('%Y-%m-%d %H:%M:%S'),
                'customer_id': cust_id,
                'card_id': card['card_id'],
                'merchant_id': merch['merchant_id'],
                'amount': amount,
                'currency': 'USD',
                'is_ecommerce': is_ecom,
                'is_cross_border': is_xb,
                'mcc': merch['mcc']
            })
        write_csv(Path(out_dir) / f'authorizations_part_{p+1:02d}.csv', rows)


auth_schema_sql = """
-- Staging table for authorization-like events used for bulk scoring
CREATE TABLE IF NOT EXISTS dispute_poc.auth_events (
  auth_id VARCHAR(36) PRIMARY KEY,
  txn_ts TIMESTAMP NOT NULL,
  customer_id VARCHAR(36) NOT NULL,
  card_id VARCHAR(19),
  merchant_id VARCHAR(20) NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  currency CHAR(3) DEFAULT 'USD',
  is_ecommerce BOOLEAN DEFAULT TRUE,
  is_cross_border BOOLEAN DEFAULT FALSE,
  mcc CHAR(4)
);
-- Example COPY command (adjust path and permissions):
-- \COPY dispute_poc.auth_events FROM 'authorizations_part_01.csv' WITH (FORMAT csv, HEADER true);

-- Bulk scoring example:
-- SELECT a.auth_id, s.*
-- FROM dispute_poc.auth_events a
-- CROSS JOIN LATERAL dispute_poc.score_dispute_risk(a.customer_id, a.merchant_id, a.amount, a.is_ecommerce, a.is_cross_border) s;
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--customers', type=int, default=10000)
    ap.add_argument('--merchants', type=int, default=1000)
    ap.add_argument('--auths', type=int, default=100000)
    ap.add_argument('--partitions', type=int, default=10)
    ap.add_argument('--out', type=str, default='./out')
    ap.add_argument('--config', type=str, default=None)
    args = ap.parse_args()

    cfg = load_cfg(args.config)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    customers = gen_customers(args.customers)
    cards = gen_cards(customers)
    merchants = gen_merchants(args.merchants)

    merchant_reputation = gen_merchant_reputation(merchants)
    customer_behavior = gen_customer_behavior(customers)
    merchant_behavior = gen_merchant_behavior(merchants)

    def w(name, rows):
        if rows:
            write_csv(out_dir / f'{name}.csv', rows, list(rows[0].keys()))

    w('customer', customers)
    w('cards', cards)
    w('merchants', merchants)
    w('merchant_reputation', merchant_reputation)
    w('customer_behavior_current', customer_behavior)
    w('merchant_behavior_current', merchant_behavior)

    gen_authorizations(customers, cards, merchants, customer_behavior, cfg, args.auths, args.partitions, out_dir)

    target_rate = float(cfg.get('target_dispute_rate', 0.008))
    fraud_ratio = float(cfg.get('fraud_ratio_of_disputes', 0.3))
    target_disputes = max(1000, int(args.auths * target_rate))

    disp_rows = []
    for _ in range(target_disputes):
        cust = random.choice(customers)
        merch = random.choice(merchants)
        reason = 'FRAUD' if random.random() < fraud_ratio else random.choice([r for r in REASON_CODES if r != 'FRAUD'])
        amount = round(random.uniform(5, 2000), 2)
        disp_rows.append({
            'dispute_id': u(),
            'txn_id': u(),
            'customer_id': cust['customer_id'],
            'merchant_id': merch['merchant_id'],
            'dispute_date': (datetime.date.today() - datetime.timedelta(days=random.randint(0, 60))).isoformat(),
            'reason_code': reason,
            'disputed_amount': amount,
            'status': random.choice(['OPEN','PENDING','CLOSED'])
        })
    w('disputes', disp_rows)

    with open(out_dir / 'auth_events_schema.sql', 'w', encoding='utf-8') as f:
        f.write(auth_schema_sql)

if __name__ == '__main__':
    main()
